# JakePOS Inventory CRUD

The Inventory CRUD module is available to both Administrator and Cashier users.

Create: Stock IN, Stock OUT, Adjustment Increase/Decrease.
Read: inventory movement records, stock balances and dashboard totals.
Update: manual inventory movements using the Edit button.
Delete: manual inventory movements using the Delete button; the stock effect is reversed safely.

POS-generated SALE and VOID movements are protected from manual editing/deletion so the sales audit trail remains intact.
