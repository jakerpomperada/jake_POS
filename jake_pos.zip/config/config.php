<?php
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/

date_default_timezone_set('Asia/Manila');

define('DB_HOST', 'localhost');
define('DB_NAME', 'jakepos');
define('DB_USER', 'root');
define('DB_PASS', '');
define('VAT_RATE', 0.12);
define('APP_NAME', 'JakePOS Version 1.0');
define('CREATOR', 'Dr. Jake R. Pomperada, PhD');
define('CURRENCY', '₱');

// Automatically determine the application URL so it works even if the
// folder is renamed or installed in a different XAMPP htdocs subfolder.
$documentRoot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : false;
$appRoot = realpath(__DIR__ . '/..');
$baseUrl = '/JakePOS_V1_BIR_Oriented';
if ($documentRoot && $appRoot && strpos(str_replace('\\','/',$appRoot), str_replace('\\','/',$documentRoot)) === 0) {
    $relative = substr(str_replace('\\','/',$appRoot), strlen(str_replace('\\','/',$documentRoot)));
    $baseUrl = $relative === '' ? '' : rtrim($relative, '/');
}
define('BASE_URL', $baseUrl);
function h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

if (!class_exists('mysqli')) {
    http_response_code(500);
    exit('<div style="font-family:Arial,sans-serif;max-width:760px;margin:60px auto;padding:24px;border:1px solid #ddd;border-radius:8px"><h2>JakePOS cannot start</h2><p>The PHP <strong>mysqli</strong> extension is not enabled.</p><p>If you are using XAMPP, open <strong>php.ini</strong>, enable <code>extension=mysqli</code>, save the file, and restart Apache.</p></div>');
}

$conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    http_response_code(500);
    exit('<div style="font-family:Arial,sans-serif;max-width:760px;margin:60px auto;padding:24px;border:1px solid #ddd;border-radius:8px"><h2>JakePOS database connection problem</h2><p>Make sure MySQL is running in XAMPP and that the <strong>jakepos</strong> database has been imported.</p><p>Database server: <strong>'.h(DB_HOST).'</strong> &nbsp; Database: <strong>'.h(DB_NAME).'</strong></p><p>Error: '.h($conn->connect_error).'</p></div>');
}
$conn->set_charset('utf8mb4');
?>
