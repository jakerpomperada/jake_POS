<?php
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
if (session_status() === PHP_SESSION_NONE) session_start();
require_once 'config/config.php';

if (empty($_SESSION['user_id'])) {
    $error = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = trim($_POST['email'] ?? '');
        $pass = $_POST['password'] ?? '';
        if ($email === '' || $pass === '') {
            $error = 'Please enter your email and password.';
        } else {
            $stmt = $conn->prepare("SELECT * FROM users WHERE email=? AND status='Active' LIMIT 1");
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $u = $stmt->get_result()->fetch_assoc();
            if ($u && password_verify($pass, $u['password'])) {
                session_regenerate_id(true);
                $_SESSION['user_id'] = (int)$u['id'];
                $_SESSION['name'] = $u['full_name'];
                $_SESSION['role'] = trim((string)$u['role']);
                $uid = (int)$u['id']; $action='LOGIN'; $module='Authentication'; $details='Successful login'; $ip=$_SERVER['REMOTE_ADDR']??'';
                $a = $conn->prepare("INSERT INTO audit_logs(user_id,action,module,details,ip_address) VALUES(?,?,?,?,?)");
                $a->bind_param('issss',$uid,$action,$module,$details,$ip); $a->execute();
                header('Location: ' . BASE_URL . '/index.php'); exit;
            }
            $error = 'Invalid email or password, or the account is inactive.';
        }
    }
    $demoAdmin = 'admin@jakepos.local';
    $demoCashier = 'cashier@jakepos.local';
    ?>
    <!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=h(APP_NAME)?> - Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css"><link rel="stylesheet" href="<?=BASE_URL?>/assets/css/jakepos.css"></head>
    <body class="hold-transition login-page jake-login"><div class="login-box" style="width:420px;max-width:94%"><div class="card card-outline card-primary shadow">
    <div class="card-header text-center py-4"><div class="h3 mb-1"><b><i class="fas fa-cash-register mr-2"></i>JakePOS</b></div><div>Version 1.0 &mdash; Philippine POS System</div></div>
    <div class="card-body"><p class="login-box-msg">Sign in to continue</p>
    <?php if($error): ?><div class="alert alert-danger"><i class="fas fa-exclamation-circle mr-1"></i><?=h($error)?></div><?php endif; ?>
    <form method="post" autocomplete="off"><div class="input-group mb-3"><input name="email" type="email" class="form-control" placeholder="Email address" required autofocus><div class="input-group-append"><div class="input-group-text"><i class="fas fa-envelope"></i></div></div></div>
    <div class="input-group mb-3"><input name="password" type="password" class="form-control" placeholder="Password" required><div class="input-group-append"><div class="input-group-text"><i class="fas fa-lock"></i></div></div></div>
    <button class="btn btn-primary btn-block btn-lg"><i class="fas fa-sign-in-alt mr-1"></i> Login</button></form>
    <hr><div class="small text-muted"><b>Demo Administrator:</b> <?=h($demoAdmin)?> / password<br><b>Demo Cashier:</b> <?=h($demoCashier)?> / password</div>
    <div class="text-center mt-3 small">Created by <b><?=h(CREATOR)?></b></div></div></div></div></body></html>
    <?php exit;
}

require_once 'includes/auth.php';
include 'includes/header.php';
$today = date('Y-m-d');
$r = $conn->query("SELECT COALESCE(SUM(total),0) s, COUNT(*) c FROM sales WHERE DATE(sale_date)='$today' AND status='Completed'")->fetch_assoc();
$p = $conn->query("SELECT COUNT(*) c FROM products WHERE status='Active'")->fetch_assoc()['c'];
$l = $conn->query("SELECT COUNT(*) c FROM products WHERE stock_qty<=reorder_level AND status='Active'")->fetch_assoc()['c'];
$cust = $conn->query("SELECT COUNT(*) c FROM customers WHERE status='Active'")->fetch_assoc()['c'];
$inv = $conn->query("SELECT COALESCE(SUM(stock_qty),0) units, COALESCE(SUM(stock_qty*price),0) value, SUM(status='Active' AND stock_qty<=reorder_level) low FROM products")->fetch_assoc();
?>
<div class="row">
<div class="col-lg-3 col-6"><div class="small-box bg-info"><div class="inner"><h3>₱<?=number_format($r['s'],2)?></h3><p>Today's Sales</p></div><div class="icon"><i class="fas fa-shopping-cart"></i></div></div></div>
<div class="col-lg-3 col-6"><div class="small-box bg-success"><div class="inner"><h3><?=h($p)?></h3><p>Active Products</p></div><div class="icon"><i class="fas fa-box"></i></div></div></div>
<div class="col-lg-3 col-6"><div class="small-box bg-warning"><div class="inner"><h3><?=h($l)?></h3><p>Low Stock</p></div><div class="icon"><i class="fas fa-exclamation-triangle"></i></div></div></div>
<div class="col-lg-3 col-6"><div class="small-box bg-primary"><div class="inner"><h3><?=h($r['c'])?></h3><p>Transactions Today</p></div><div class="icon"><i class="fas fa-receipt"></i></div></div></div>
</div>
<div class="row"><div class="col-md-4"><div class="card card-warning"><div class="card-header"><h3 class="card-title"><i class="fas fa-warehouse mr-1"></i>Inventory Snapshot</h3></div><div class="card-body"><p><b>Units:</b> <?=number_format($inv['units'])?></p><p><b>Value:</b> <?=CURRENCY?><?=number_format($inv['value'],2)?></p><p><b>Low Stock:</b> <span class="badge badge-warning"><?=number_format($inv['low'])?></span></p><a href="<?=BASE_URL?>/modules/inventory/index.php" class="btn btn-warning btn-sm mr-1">Manage Inventory</a><a href="<?=BASE_URL?>/modules/reports/inventory.php" class="btn btn-outline-secondary btn-sm">Inventory Reports</a></div></div></div><div class="col-md-8"><div class="card card-primary"><div class="card-header"><h3 class="card-title">Quick Actions</h3></div><div class="card-body"><a href="<?=BASE_URL?>/pos.php" class="btn btn-success mr-2 mb-2"><i class="fas fa-cash-register mr-1"></i> New Sale</a><a href="<?=BASE_URL?>/modules/customers/index.php" class="btn btn-info mr-2 mb-2"><i class="fas fa-users mr-1"></i> Customers</a><a href="<?=BASE_URL?>/modules/reports/sales.php" class="btn btn-secondary mr-2 mb-2"><i class="fas fa-chart-line mr-1"></i> Sales Report</a><?php if(is_admin()): ?><a href="<?=BASE_URL?>/modules/products/index.php" class="btn btn-warning mb-2"><i class="fas fa-box mr-1"></i> Products</a><?php endif; ?></div></div></div>
<div class="col-md-4"><div class="card card-success"><div class="card-header"><h3 class="card-title">System Status</h3></div><div class="card-body"><p><i class="fas fa-check-circle text-success mr-1"></i> Database connected</p><p><i class="fas fa-peso-sign mr-1"></i> Currency: Philippine Peso</p><p><i class="fas fa-percent mr-1"></i> VAT: 12%</p><p><i class="fas fa-clock mr-1"></i> Timezone: Asia/Manila</p><p><i class="fas fa-users mr-1"></i> Active Customers: <?=h($cust)?></p></div></div></div></div>
<div class="alert alert-info"><b>BIR-oriented prototype:</b> Includes 12% VAT, sequential invoice numbers, X/Z readings, Audit Journal, sales/VAT reports and eSales-ready fields. Actual BIR registration/accreditation is separate.</div>
<?php include 'includes/footer.php'; ?>
