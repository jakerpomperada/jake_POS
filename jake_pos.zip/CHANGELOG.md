# JakePOS Version 1.0 - Change Log

## CRUD and usability update
- `index.php` is now the application entry point and displays the login screen before authentication.
- `login.php` is retained as a compatibility redirect to `index.php`.
- Added complete create/read/update/status management for Users, Products and Customers.
- Added true CRUD for Inventory Movements with stock-safe transaction handling.
- Added Sales Management with receipt viewing and administrator-only sale voiding. Voiding restores stock and records an inventory movement.
- Improved POS checkout validation, cart quantity controls, cash/change display and inventory logging.
- Added CSRF protection to management POST operations.
- Audit Journal is accessible to all authenticated users according to role and is intentionally immutable; filtering and printing are provided.
- Added clearer dashboard quick actions and module navigation.
- Sales report totals exclude voided transactions.
- PHP syntax checked across all application PHP files with no syntax errors.

## Previous fixes retained
- Dynamic BASE_URL for XAMPP/folder-renaming compatibility.
- Valid demo password hash for both demo accounts.
- PHP 7.4-compatible URL-prefix handling.
- Administrator/Cashier role controls.
- Philippine Peso, 12% VAT, invoice sequencing, X/Z readings, receipts and audit logging.

## Important
JakePOS remains a BIR-oriented prototype. Actual BIR registration/accreditation and taxpayer-specific compliance must be handled separately.
