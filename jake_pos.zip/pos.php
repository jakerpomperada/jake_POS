<?php
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
require_once 'includes/auth.php'; require_login();
$msg='';$err='';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['complete_sale'])){
    verify_csrf();
    $cart=json_decode($_POST['cart_json']??'[]',true); $cash=(float)($_POST['cash']??0); $customer=(int)($_POST['customer_id']??0);
    if(!is_array($cart)||!count($cart)) $err='Cart is empty. Please add at least one product.';
    elseif($cash<0) $err='Cash received cannot be negative.';
    else {
        $subtotal=0; $items=[];
        foreach($cart as $x){
            $pid=(int)($x['id']??0);$qty=(int)($x['qty']??0);
            if($pid<1||$qty<1) continue;
            $st=$conn->prepare("SELECT id,product_name,price,stock_qty FROM products WHERE id=? AND status='Active' FOR UPDATE");$st->bind_param('i',$pid);$st->execute();$p=$st->get_result()->fetch_assoc();
            if(!$p){$err='One of the selected products is no longer available.';break;}
            if((int)$p['stock_qty']<$qty){$err='Insufficient stock for '.h($p['product_name']).'. Available: '.(int)$p['stock_qty'];break;}
            $line=round((float)$p['price']*$qty,2);$subtotal+=$line;$items[]=['id'=>$pid,'name'=>$p['product_name'],'qty'=>$qty,'price'=>(float)$p['price'],'line'=>$line];
        }
        if(!$err && !$items)$err='Please add valid products to the cart.';
        if(!$err){
            $vat=round($subtotal*VAT_RATE,2);$total=round($subtotal+$vat,2);
            if($cash+0.00001<$total)$err='Cash received is less than the total amount of ₱'.number_format($total,2).'.';
            elseif($customer>0){$st=$conn->prepare("SELECT id FROM customers WHERE id=? AND status='Active'");$st->bind_param('i',$customer);$st->execute();if(!$st->get_result()->fetch_assoc())$err='The selected customer is not active.';}
        }
        if(!$err){
            $conn->begin_transaction();
            try{
                $invoice=next_invoice_no();$change=round($cash-$total,2);$uid=(int)$_SESSION['user_id'];
                $st=$conn->prepare("INSERT INTO sales(invoice_no,customer_id,user_id,subtotal,vat_rate,vat_amount,total,cash_received,change_amount,status,sale_date) VALUES(?,?,?,?,?,?,?,?,?,'Completed',NOW())");
                $st->bind_param('siidddddd',$invoice,$customer,$uid,$subtotal,$vat,$vat,$total,$cash,$change);$st->execute();$sale_id=$conn->insert_id;
                $it=$conn->prepare("INSERT INTO sale_items(sale_id,product_id,product_name,qty,unit_price,line_total) VALUES(?,?,?,?,?,?)");
                $up=$conn->prepare("UPDATE products SET stock_qty=stock_qty-? WHERE id=? AND stock_qty>=?");
                $mv=$conn->prepare("INSERT INTO inventory_movements(product_id,movement_type,qty,unit_cost,reference_no,notes,user_id,source_type,sale_id) VALUES(?,'OUT',?,?,?,?,?,'SALE',?)");
                foreach($items as $x){
                    $it->bind_param('iisidd',$sale_id,$x['id'],$x['name'],$x['qty'],$x['price'],$x['line']);$it->execute();
                    $up->bind_param('iii',$x['qty'],$x['id'],$x['qty']);$up->execute();
                    if($up->affected_rows<1)throw new Exception('Stock changed while the sale was being processed. Please try again.');
                    $note='POS Sale '.$invoice; $ref=$invoice; $cost=$x['price'];
                    $mv->bind_param('iidssii',$x['id'],$x['qty'],$cost,$ref,$note,$uid,$sale_id);$mv->execute();
                }
                audit_log('SALE','POS','Invoice '.$invoice.' completed');$conn->commit();header('Location: receipt.php?id='.$sale_id);exit;
            }catch(Throwable $e){$conn->rollback();$err='The sale could not be completed. '.$e->getMessage();}
        }
    }
}
include 'includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3"><div><h2 class="mb-0">Point of Sale</h2><small class="text-muted">Fast Philippine retail checkout &mdash; <?=h(CURRENCY)?> and 12% VAT.</small></div><a href="<?=BASE_URL?>/modules/customers/index.php" class="btn btn-outline-primary">Manage Customers</a></div>
<?php if($err):?><div class="alert alert-danger"><i class="fas fa-exclamation-circle mr-1"></i><?=h($err)?></div><?php endif;?>
<form method="post" id="posForm"><input type="hidden" name="csrf_token" value="<?=h(csrf_token())?>"><input type="hidden" name="complete_sale" value="1"><input type="hidden" name="cart_json" id="cart_json">
<div class="row"><div class="col-lg-8"><div class="card card-primary"><div class="card-header"><h3 class="card-title">Products</h3></div><div class="card-body"><div class="form-group"><label>Search / Select Product</label><select id="productSelect" class="form-control"><option value="">Select product</option><?php $q=$conn->query("SELECT id,product_name,price,stock_qty FROM products WHERE status='Active' AND stock_qty>0 ORDER BY product_name");while($p=$q->fetch_assoc()):?><option value="<?=$p['id']?>" data-name="<?=h($p['product_name'])?>" data-price="<?=$p['price']?>" data-stock="<?=$p['stock_qty']?>"><?=h($p['product_name'])?> &mdash; ₱<?=number_format($p['price'],2)?> (Stock <?=$p['stock_qty']?>)</option><?php endwhile;?></select></div><button type="button" class="btn btn-secondary mb-3" onclick="addItem()"><i class="fas fa-cart-plus mr-1"></i>Add to Cart</button>
<div class="table-responsive"><table class="table table-bordered table-hover" id="cartTable"><thead><tr><th>Product</th><th style="width:130px">Qty</th><th>Unit Price</th><th>Amount</th><th style="width:60px"></th></tr></thead><tbody></tbody></table></div></div></div></div>
<div class="col-lg-4"><div class="card card-success"><div class="card-header"><h3 class="card-title">Checkout</h3></div><div class="card-body"><div class="form-group"><label>Customer</label><select name="customer_id" class="form-control"><option value="0">Walk-in Customer</option><?php $cq=$conn->query("SELECT id,customer_name FROM customers WHERE status='Active' ORDER BY customer_name");while($c=$cq->fetch_assoc()):?><option value="<?=$c['id']?>"><?=h($c['customer_name'])?></option><?php endwhile;?></select></div><div class="summary-box p-3 mb-3"><div class="d-flex justify-content-between"><span>Subtotal</span><b>₱<span id="sub">0.00</span></b></div><div class="d-flex justify-content-between"><span>VAT (12%)</span><b>₱<span id="vat">0.00</span></b></div><hr><div class="d-flex justify-content-between"><strong>Total</strong><strong class="text-success">₱<span id="total">0.00</span></strong></div></div><div class="form-group"><label>Cash Received</label><input type="number" step="0.01" min="0" name="cash" id="cash" class="form-control form-control-lg" required></div><div class="alert alert-light">Change: <strong>₱<span id="change">0.00</span></strong></div><button class="btn btn-success btn-lg btn-block"><i class="fas fa-check mr-1"></i>Complete Sale &amp; Print Receipt</button></div></div></div></div></form>
<script>
let cart=[];
function addItem(){const s=document.getElementById('productSelect'),o=s.options[s.selectedIndex];if(!o.value)return;const id=Number(o.value),stock=Number(o.dataset.stock),found=cart.find(x=>x.id===id);if(found){if(found.qty<stock)found.qty++;else alert('Maximum available stock is '+stock+'.');}else cart.push({id:id,name:o.dataset.name,price:Number(o.dataset.price),qty:1,stock:stock});render();s.selectedIndex=0;}
function removeItem(i){cart.splice(i,1);render();}
function setQty(i,v){v=Math.max(1,Math.min(Number(v)||1,cart[i].stock));cart[i].qty=v;render();}
function render(){const tb=document.querySelector('#cartTable tbody');tb.innerHTML='';let sub=0;cart.forEach((x,i)=>{const a=x.price*x.qty;sub+=a;tb.innerHTML+=`<tr><td>${escapeHtml(x.name)}</td><td><input type="number" min="1" max="${x.stock}" value="${x.qty}" onchange="setQty(${i},this.value)" class="form-control"></td><td>₱${x.price.toFixed(2)}</td><td>₱${a.toFixed(2)}</td><td><button type="button" onclick="removeItem(${i})" class="btn btn-danger btn-sm"><i class="fas fa-times"></i></button></td></tr>`});const vat=Math.round(sub*.12*100)/100,total=Math.round((sub+vat)*100)/100;document.getElementById('sub').textContent=sub.toFixed(2);document.getElementById('vat').textContent=vat.toFixed(2);document.getElementById('total').textContent=total.toFixed(2);document.getElementById('cart_json').value=JSON.stringify(cart);updateChange();}
function updateChange(){const total=Number(document.getElementById('total').textContent)||0,cash=Number(document.getElementById('cash').value)||0;document.getElementById('change').textContent=Math.max(0,cash-total).toFixed(2);}
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
document.getElementById('cash').addEventListener('input',updateChange);document.getElementById('posForm').addEventListener('submit',e=>{if(!cart.length){e.preventDefault();alert('Please add at least one item to the cart.');}else{const total=Number(document.getElementById('total').textContent)||0;if(Number(document.getElementById('cash').value)<total){e.preventDefault();alert('Cash received is less than the total.');}}});
</script>
<?php include 'includes/footer.php'; ?>
