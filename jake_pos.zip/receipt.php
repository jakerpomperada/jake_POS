<?php 
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
require_once 'includes/auth.php'; include 'includes/header.php';
$id=(int)($_GET['id']??0);$st=$conn->prepare("SELECT s.*,c.customer_name,u.full_name FROM sales s LEFT JOIN customers c ON c.id=s.customer_id JOIN users u ON u.id=s.user_id WHERE s.id=?");$st->bind_param("i",$id);$st->execute();$sale=$st->get_result()->fetch_assoc();
if(!$sale){echo '<div class="alert alert-danger">Sale not found.</div>';include 'includes/footer.php';exit;}
$it=$conn->prepare("SELECT * FROM sale_items WHERE sale_id=?");$it->bind_param("i",$id);$it->execute();$items=$it->get_result();
?>
<div class="card"><div class="card-header"><button class="btn btn-primary float-right" onclick="window.print()">Print</button></div><div class="card-body">
<div class="receipt"><center><b>JakePOS Version 1.0</b><br>Created by Dr. Jake R. Pomperada, PhD<br><b>INVOICE</b></center>
<hr>Invoice No: <?=h($sale['invoice_no'])?><br>Date: <?=h($sale['sale_date'])?><br>Cashier: <?=h($sale['full_name'])?><br>Customer: <?=h($sale['customer_name']??'Walk-in Customer')?><hr>
<?php while($x=$items->fetch_assoc()): ?><div><?=h($x['product_name'])?><br><?=h($x['qty'])?> x ₱<?=number_format($x['unit_price'],2)?> = ₱<?=number_format($x['line_total'],2)?></div><?php endwhile;?>
<hr>Subtotal: ₱<?=number_format($sale['subtotal'],2)?><br>VAT (12%): ₱<?=number_format($sale['vat_amount'],2)?><br><b>Total: ₱<?=number_format($sale['total'],2)?></b><br>Cash: ₱<?=number_format($sale['cash_received'],2)?><br>Change: ₱<?=number_format($sale['change_amount'],2)?><hr>
<center>Thank you for your purchase!</center></div>
</div></div>
<?php include 'includes/footer.php'; ?>
