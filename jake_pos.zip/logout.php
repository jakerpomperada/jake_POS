<?php
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
// JakePOS secure logout - PHP 7.4/8.x compatible
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/config/config.php';

if (!empty($_SESSION['user_id'])) {
    $uid = (int)$_SESSION['user_id'];
    $action = 'LOGOUT';
    $module = 'Authentication';
    $details = 'User logged out';
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $st = $conn->prepare("INSERT INTO audit_logs(user_id,action,module,details,ip_address) VALUES(?,?,?,?,?)");
    if ($st) {
        $st->bind_param('issss', $uid, $action, $module, $details, $ip);
        $st->execute();
        $st->close();
    }
}

// Remove all session data first.
$_SESSION = [];

// Expire the session cookie. PHP 8 requires an integer timestamp or options array;
// never pass 'time()-42000' as a quoted string.
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', [
        'expires'  => time() - 42000,
        'path'     => $p['path'] ?? '/',
        'domain'   => $p['domain'] ?? '',
        'secure'   => (bool)($p['secure'] ?? false),
        'httponly' => (bool)($p['httponly'] ?? false),
        'samesite' => $p['samesite'] ?? 'Lax'
    ]);
}

session_destroy();
header('Location: ' . BASE_URL . '/index.php');
exit;
?>
