USE jakepos;
-- -------------------------------------------------------------------------
-- JakePOS Version 1.0
-- Philippine Point of Sale and Inventory System
-- -------------------------------------------------------------------------
-- Programming Language : SQL
-- Database             : MySQL
-- Created By           : Dr. Jake Rodriguez Pomperada, PhD
-- Date Created         : September 29, 2026
-- Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
--
-- This database script was developed for JakePOS.
-- All rights reserved.
-- -------------------------------------------------------------------------
-- JakePOS Inventory schema upgrade for older installations.
-- Safe to run once in phpMyAdmin. The Inventory module also performs
-- a compatibility check automatically when opened.

SET @db = DATABASE();

SET @sql = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='inventory_movements' AND COLUMN_NAME='unit_cost')=0,
  'ALTER TABLE inventory_movements ADD COLUMN unit_cost DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER qty',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='inventory_movements' AND COLUMN_NAME='reference_no')=0,
  'ALTER TABLE inventory_movements ADD COLUMN reference_no VARCHAR(80) DEFAULT NULL AFTER unit_cost',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='inventory_movements' AND COLUMN_NAME='source_type')=0,
  'ALTER TABLE inventory_movements ADD COLUMN source_type ENUM(''MANUAL'',''SALE'',''VOID'',''OPENING'') NOT NULL DEFAULT ''MANUAL'' AFTER user_id',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='inventory_movements' AND COLUMN_NAME='sale_id')=0,
  'ALTER TABLE inventory_movements ADD COLUMN sale_id INT DEFAULT NULL AFTER source_type',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql = IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='inventory_movements' AND COLUMN_NAME='adjustment_direction')=0,
  'ALTER TABLE inventory_movements ADD COLUMN adjustment_direction ENUM(''INCREASE'',''DECREASE'') DEFAULT NULL AFTER sale_id',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

CREATE INDEX idx_inventory_product_date ON inventory_movements(product_id, movement_date);
CREATE INDEX idx_inventory_source ON inventory_movements(source_type);
