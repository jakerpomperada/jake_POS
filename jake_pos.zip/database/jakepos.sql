-- -------------------------------------------------------------------------
-- JakePOS Version 1.0
-- Philippine Point of Sale and Inventory System
-- -------------------------------------------------------------------------
-- Programming Language : SQL
-- Database             : MySQL
-- Created By           : Dr. Jake Rodriguez Pomperada, PhD
-- Date Created         : September 29, 2026
-- Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
--
-- This database script was developed for JakePOS.
-- All rights reserved.
-- -------------------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS jakepos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE jakepos;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS inventory_movements;
DROP TABLE IF EXISTS sale_items;
DROP TABLE IF EXISTS sales;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE users(
 id INT AUTO_INCREMENT PRIMARY KEY,
 full_name VARCHAR(150) NOT NULL,
 email VARCHAR(150) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL,
 role ENUM('Administrator','Cashier') NOT NULL DEFAULT 'Cashier',
 status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE products(
 id INT AUTO_INCREMENT PRIMARY KEY,
 sku VARCHAR(50) NOT NULL UNIQUE,
 product_name VARCHAR(150) NOT NULL,
 price DECIMAL(12,2) NOT NULL DEFAULT 0,
 stock_qty INT NOT NULL DEFAULT 0,
 reorder_level INT NOT NULL DEFAULT 5,
 status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE customers(
 id INT AUTO_INCREMENT PRIMARY KEY,
 customer_name VARCHAR(150) NOT NULL,
 tin VARCHAR(30) DEFAULT NULL,
 address VARCHAR(255) DEFAULT NULL,
 status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE sales(
 id INT AUTO_INCREMENT PRIMARY KEY,
 invoice_no VARCHAR(40) NOT NULL UNIQUE,
 customer_id INT DEFAULT 0,
 user_id INT NOT NULL,
 subtotal DECIMAL(12,2) NOT NULL,
 vat_rate DECIMAL(5,4) NOT NULL DEFAULT 0.1200,
 vat_amount DECIMAL(12,2) NOT NULL,
 total DECIMAL(12,2) NOT NULL,
 cash_received DECIMAL(12,2) NOT NULL,
 change_amount DECIMAL(12,2) NOT NULL,
 status ENUM('Completed','Voided') NOT NULL DEFAULT 'Completed',
 sale_date DATETIME NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE sale_items(
 id INT AUTO_INCREMENT PRIMARY KEY,
 sale_id INT NOT NULL,
 product_id INT NOT NULL,
 product_name VARCHAR(150) NOT NULL,
 qty INT NOT NULL,
 unit_price DECIMAL(12,2) NOT NULL,
 line_total DECIMAL(12,2) NOT NULL,
 FOREIGN KEY(sale_id) REFERENCES sales(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE inventory_movements(
 id INT AUTO_INCREMENT PRIMARY KEY,
 product_id INT NOT NULL,
 movement_type ENUM('IN','OUT','ADJUSTMENT') NOT NULL,
 qty INT NOT NULL,
 unit_cost DECIMAL(12,2) NOT NULL DEFAULT 0,
 reference_no VARCHAR(80) DEFAULT NULL,
 notes VARCHAR(255) DEFAULT NULL,
 user_id INT NOT NULL,
 source_type ENUM('MANUAL','SALE','VOID','OPENING') NOT NULL DEFAULT 'MANUAL',
 sale_id INT DEFAULT NULL,
 adjustment_direction ENUM('INCREASE','DECREASE') DEFAULT NULL,
 movement_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(product_id) REFERENCES products(id),
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(sale_id) REFERENCES sales(id) ON DELETE SET NULL,
 INDEX idx_inventory_product_date(product_id,movement_date),
 INDEX idx_inventory_source(source_type)
) ENGINE=InnoDB;

CREATE TABLE audit_logs(
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NULL,
 action VARCHAR(80) NOT NULL,
 module VARCHAR(80) NOT NULL,
 details TEXT,
 ip_address VARCHAR(64),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Demo password for both accounts: password
INSERT INTO users(full_name,email,password,role) VALUES
('Dr. Jake R. Pomperada','admin@jakepos.local','$2y$12$XEbdq9Uvu.y7JfdL2rZpc.UPUpoJcwMnGlVZPXVedNKIaCBwMsP1W','Administrator'),
('Juan Dela Cruz','cashier@jakepos.local','$2y$12$XEbdq9Uvu.y7JfdL2rZpc.UPUpoJcwMnGlVZPXVedNKIaCBwMsP1W','Cashier');

INSERT INTO products(sku,product_name,price,stock_qty,reorder_level) VALUES
('PEN-001','Ballpen',10.00,90,10),
('NOTE-001','Notebook',35.00,70,10),
('PEN-002','Pencil',5.00,120,20),
('ERAS-001','Eraser',8.00,75,10),
('INK-001','Printer Ink',250.00,25,5),
('PPR-001','Bond Paper A4',250.00,40,5),
('USB-001','USB Flash Drive 32GB',350.00,30,5),
('MOU-001','USB Mouse',450.00,18,5);

INSERT INTO customers(customer_name,tin,address) VALUES
('Walk-in Customer',NULL,''),
('ABC Learning Center','123-456-789-000','Bacolod City, Negros Occidental'),
('Sample Enterprise','987-654-321-000','Talisay City, Negros Occidental');

INSERT INTO sales(invoice_no,customer_id,user_id,subtotal,vat_rate,vat_amount,total,cash_received,change_amount,status,sale_date) VALUES
('202609-000001',2,1,1000.00,0.1200,120.00,1120.00,1200.00,80.00,'Completed','2026-09-29 09:30:00'),
('202609-000002',1,2,500.00,0.1200,60.00,560.00,600.00,40.00,'Completed','2026-09-29 10:15:00');

INSERT INTO sale_items(sale_id,product_id,product_name,qty,unit_price,line_total) VALUES
(1,8,'USB Mouse',2,450.00,900.00),
(1,1,'Ballpen',10,10.00,100.00),
(2,2,'Notebook',10,35.00,350.00),
(2,3,'Pencil',30,5.00,150.00);

-- Opening balances and sample POS movements. Current product stocks above already reflect these sales.
INSERT INTO inventory_movements(product_id,movement_type,qty,unit_cost,reference_no,notes,user_id,source_type,sale_id,movement_date) VALUES
(1,'IN',100,5.00,'OPEN-001','Opening inventory',1,'OPENING',NULL,'2026-09-29 08:00:00'),
(2,'IN',80,20.00,'OPEN-001','Opening inventory',1,'OPENING',NULL,'2026-09-29 08:00:00'),
(3,'IN',150,2.00,'OPEN-001','Opening inventory',1,'OPENING',NULL,'2026-09-29 08:00:00'),
(4,'IN',75,3.00,'OPEN-001','Opening inventory',1,'OPENING',NULL,'2026-09-29 08:00:00'),
(5,'IN',25,180.00,'OPEN-001','Opening inventory',1,'OPENING',NULL,'2026-09-29 08:00:00'),
(6,'IN',40,180.00,'OPEN-001','Opening inventory',1,'OPENING',NULL,'2026-09-29 08:00:00'),
(7,'IN',30,250.00,'OPEN-001','Opening inventory',1,'OPENING',NULL,'2026-09-29 08:00:00'),
(8,'IN',20,300.00,'OPEN-001','Opening inventory',1,'OPENING',NULL,'2026-09-29 08:00:00'),
(8,'OUT',2,450.00,'202609-000001','POS Sale 202609-000001',1,'SALE',1,'2026-09-29 09:30:00'),
(1,'OUT',10,10.00,'202609-000001','POS Sale 202609-000001',1,'SALE',1,'2026-09-29 09:30:00'),
(2,'OUT',10,35.00,'202609-000002','POS Sale 202609-000002',2,'SALE',2,'2026-09-29 10:15:00'),
(3,'OUT',30,5.00,'202609-000002','POS Sale 202609-000002',2,'SALE',2,'2026-09-29 10:15:00');
