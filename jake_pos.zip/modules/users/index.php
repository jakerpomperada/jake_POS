<?php
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
require_once '../../includes/auth.php'; require_admin();
$msg=''; $error=''; $edit=null;
if(isset($_GET['edit'])){ $id=(int)$_GET['edit']; $st=$conn->prepare("SELECT id,full_name,email,role,status FROM users WHERE id=?"); $st->bind_param('i',$id); $st->execute(); $edit=$st->get_result()->fetch_assoc(); }
if(isset($_GET['toggle'])){
    $id=(int)$_GET['toggle'];
    if($id===(int)$_SESSION['user_id']) $error='You cannot deactivate your own account while logged in.';
    else { $st=$conn->prepare("UPDATE users SET status=IF(status='Active','Inactive','Active') WHERE id=?"); $st->bind_param('i',$id); if($st->execute()) audit_log('STATUS','Users','User ID '.$id); redirect_to('modules/users/index.php'); }
}
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf(); $id=(int)($_POST['id']??0); $name=trim($_POST['full_name']??''); $email=trim($_POST['email']??''); $role=$_POST['role']??'Cashier'; $status=$_POST['status']??'Active'; $password=$_POST['password']??'';
    if($name===''||!filter_var($email,FILTER_VALIDATE_EMAIL)) $error='Please enter a valid name and email address.';
    elseif(!in_array($role,['Administrator','Cashier'],true)||!in_array($status,['Active','Inactive'],true)) $error='Invalid role or status.';
    else {
        try {
            if($id){
                if($password!==''){ $hash=password_hash($password,PASSWORD_DEFAULT); $st=$conn->prepare("UPDATE users SET full_name=?,email=?,role=?,status=?,password=? WHERE id=?"); $st->bind_param('sssssi',$name,$email,$role,$status,$hash,$id); }
                else { $st=$conn->prepare("UPDATE users SET full_name=?,email=?,role=?,status=? WHERE id=?"); $st->bind_param('ssssi',$name,$email,$role,$status,$id); }
                $st->execute(); audit_log('UPDATE','Users',$email); $msg='User updated successfully.';
            } else {
                if($password==='') $error='Password is required when creating a user.';
                else { $hash=password_hash($password,PASSWORD_DEFAULT); $st=$conn->prepare("INSERT INTO users(full_name,email,password,role,status) VALUES(?,?,?,?,?)"); $st->bind_param('sssss',$name,$email,$hash,$role,$status); $st->execute(); audit_log('CREATE','Users',$email); $msg='User created successfully.'; }
            }
        } catch(Throwable $e) { $error = $e->getCode()==='23000' ? 'That email address is already registered.' : 'Unable to save the user.'; }
        if($msg) $edit=null;
    }
}
include '../../includes/header.php';
$users=$conn->query("SELECT id,full_name,email,role,status,created_at FROM users ORDER BY id DESC");
?>
<div class="d-flex justify-content-between align-items-center mb-3"><div><h2 class="mb-0">User Management</h2><small class="text-muted">Create, edit, activate and deactivate system accounts.</small></div></div>
<?php if($msg): ?><div class="alert alert-success"><?=h($msg)?></div><?php endif;?><?php if($error): ?><div class="alert alert-danger"><?=h($error)?></div><?php endif;?>
<div class="card card-primary"><div class="card-header"><h3 class="card-title"><i class="fas fa-user-cog mr-1"></i><?= $edit?'Edit User':'Add User' ?></h3></div><div class="card-body"><form method="post" class="row"><input type="hidden" name="csrf_token" value="<?=h(csrf_token())?>"><input type="hidden" name="id" value="<?=h($edit['id']??0)?>">
<div class="col-md-3 mb-2"><label>Full Name</label><input name="full_name" class="form-control" required value="<?=h($edit['full_name']??'')?>"></div><div class="col-md-3 mb-2"><label>Email</label><input name="email" type="email" class="form-control" required value="<?=h($edit['email']??'')?>"></div><div class="col-md-2 mb-2"><label>Role</label><select name="role" class="form-control"><option <?=($edit['role']??'Cashier')==='Cashier'?'selected':''?>>Cashier</option><option <?=($edit['role']??'')==='Administrator'?'selected':''?>>Administrator</option></select></div><div class="col-md-2 mb-2"><label>Status</label><select name="status" class="form-control"><option <?=($edit['status']??'Active')==='Active'?'selected':''?>>Active</option><option <?=($edit['status']??'')==='Inactive'?'selected':''?>>Inactive</option></select></div><div class="col-md-2 mb-2"><label>Password <?= $edit?'<small>(optional)</small>':'' ?></label><input name="password" type="password" class="form-control" <?= $edit?'':'required' ?>></div>
<div class="col-12 mt-2"><button class="btn btn-success"><i class="fas fa-save mr-1"></i><?= $edit?'Update User':'Create User' ?></button><?php if($edit): ?><a href="<?=BASE_URL?>/modules/users/index.php" class="btn btn-secondary ml-2">Cancel</a><?php endif;?></div></form></div></div>
<div class="card"><div class="card-header"><h3 class="card-title">Users</h3></div><div class="card-body table-responsive p-0"><table class="table table-hover table-striped mb-0"><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Created</th><th class="text-right">Actions</th></tr></thead><tbody>
<?php while($u=$users->fetch_assoc()): ?><tr><td><?=$u['id']?></td><td><?=h($u['full_name'])?></td><td><?=h($u['email'])?></td><td><?=h($u['role'])?></td><td><span class="badge badge-<?=$u['status']==='Active'?'success':'secondary'?>"><?=h($u['status'])?></span></td><td><?=h($u['created_at'])?></td><td class="text-right text-nowrap"><a href="?edit=<?=$u['id']?>" class="btn btn-sm btn-info"><i class="fas fa-edit"></i> Edit</a> <?php if((int)$u['id']!==(int)$_SESSION['user_id']): ?><a href="?toggle=<?=$u['id']?>" onclick="return confirm('Change this user status?')" class="btn btn-sm btn-<?=$u['status']==='Active'?'warning':'success'?>"><?= $u['status']==='Active'?'Deactivate':'Activate' ?></a><?php endif;?></td></tr><?php endwhile;?></tbody></table></div></div>
<?php include '../../includes/footer.php'; ?>
