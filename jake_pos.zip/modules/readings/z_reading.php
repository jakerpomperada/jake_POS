<?php
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
require_once '../../includes/auth.php'; include '../../includes/header.php';
$d=$_GET['date']??date('Y-m-d');$st=$conn->prepare("SELECT COALESCE(SUM(subtotal),0) net,COALESCE(SUM(vat_amount),0) vat,COALESCE(SUM(total),0) gross,COUNT(*) tx,COALESCE(MAX(invoice_no),'N/A') last_invoice FROM sales WHERE DATE(sale_date)=? AND status='Completed'");$st->bind_param("s",$d);$st->execute();$r=$st->get_result()->fetch_assoc();
?>
<div class="card"><div class="card-header"><h3 class="card-title">Z-Reading / End-of-Day Report</h3><button onclick="window.print()" class="btn btn-primary float-right">Print</button></div><div class="card-body"><form class="form-inline mb-3"><input type="date" name="date" value="<?=$d?>" class="form-control mr-2"><button class="btn btn-secondary">Generate</button></form>
<h4>JakePOS Version 1.0</h4><p><b>Z-Reading Date:</b> <?=$d?></p><table class="table table-bordered"><tr><th>Total Transactions</th><th>VATable Sales Net</th><th>VAT 12%</th><th>Gross Sales</th><th>End Invoice Range</th></tr><tr><td><?=$r['tx']?></td><td>₱<?=number_format($r['net'],2)?></td><td>₱<?=number_format($r['vat'],2)?></td><td>₱<?=number_format($r['gross'],2)?></td><td><?=h($r['last_invoice'])?></td></tr></table><hr><p>Prepared by: <?=h($_SESSION['name'])?></p><p><b>Note:</b> This software report is a BIR-oriented prototype and is not itself proof of BIR accreditation.</p>
</div></div><?php include '../../includes/footer.php'; ?>
