<?php
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
require_once '../../includes/auth.php';
require_login();

// Backward-compatible schema upgrade for installations using the older
// inventory_movements table. This prevents undefined-array-key warnings and
// enables the complete Inventory CRUD module without requiring a manual SQL
// migration first. The operation is idempotent.
$requiredColumns = [
    'unit_cost' => "DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER qty",
    'reference_no' => "VARCHAR(80) DEFAULT NULL AFTER unit_cost",
    'source_type' => "ENUM('MANUAL','SALE','VOID','OPENING') NOT NULL DEFAULT 'MANUAL' AFTER user_id",
    'sale_id' => "INT DEFAULT NULL AFTER source_type",
    'adjustment_direction' => "ENUM('INCREASE','DECREASE') DEFAULT NULL AFTER sale_id"
];
foreach ($requiredColumns as $column => $definition) {
    $check = $conn->prepare("SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='inventory_movements' AND COLUMN_NAME=?");
    $check->bind_param('s', $column);
    $check->execute();
    $exists = (int)$check->get_result()->fetch_assoc()['c'] > 0;
    if (!$exists) {
        if (!$conn->query("ALTER TABLE inventory_movements ADD COLUMN `$column` $definition")) {
            die('Inventory database upgrade failed while adding ' . h($column) . ': ' . h($conn->error));
        }
    }
}

$msg=''; $error=''; $edit=null; $view=null;

if (isset($_GET['edit'])) {
    $id=(int)$_GET['edit'];
    $st=$conn->prepare("SELECT * FROM inventory_movements WHERE id=? AND source_type='MANUAL'");
    $st->bind_param('i',$id); $st->execute(); $edit=$st->get_result()->fetch_assoc();
    if (!$edit) { $error='Only manual inventory movements can be edited.'; }
}

if (isset($_GET['view'])) {
    $id=(int)$_GET['view'];
    $st=$conn->prepare("SELECT m.*,p.sku,p.product_name,u.full_name FROM inventory_movements m JOIN products p ON p.id=m.product_id JOIN users u ON u.id=m.user_id WHERE m.id=?");
    $st->bind_param('i',$id); $st->execute(); $view=$st->get_result()->fetch_assoc();
    if (!$view) $error='Inventory movement not found.';
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $id=(int)($_POST['id']??0);
    $product=(int)($_POST['product_id']??0);
    $type=$_POST['movement_type']??'IN';
    $qty=(int)($_POST['qty']??0);
    $unit_cost=(float)($_POST['unit_cost']??0);
    $reference=trim($_POST['reference_no']??'');
    $notes=trim($_POST['notes']??'');
    $direction=$_POST['adjustment_direction']??'INCREASE';

    if ($product<1 || $qty<1 || !in_array($type,['IN','OUT','ADJUSTMENT'],true)) {
        $error='Select a product, valid movement type, and quantity greater than zero.';
    } elseif ($unit_cost<0) {
        $error='Unit cost cannot be negative.';
    } elseif ($type==='ADJUSTMENT' && !in_array($direction,['INCREASE','DECREASE'],true)) {
        $error='Select an adjustment direction.';
    } else {
        $conn->begin_transaction();
        try {
            $deltaNew = ($type==='IN' || ($type==='ADJUSTMENT' && $direction==='INCREASE')) ? $qty : -$qty;

            if ($id) {
                $st=$conn->prepare("SELECT product_id,movement_type,qty,adjustment_direction FROM inventory_movements WHERE id=? AND source_type='MANUAL' FOR UPDATE");
                $st->bind_param('i',$id); $st->execute(); $old=$st->get_result()->fetch_assoc();
                if (!$old) throw new Exception('Manual inventory movement not found.');
                $oldDelta = ($old['movement_type']==='IN' || ($old['movement_type']==='ADJUSTMENT' && $old['adjustment_direction']==='INCREASE')) ? (int)$old['qty'] : -(int)$old['qty'];
                $reverse=-$oldDelta;

                $up=$conn->prepare("UPDATE products SET stock_qty=stock_qty+? WHERE id=? AND stock_qty+? >= 0");
                $up->bind_param('iii',$reverse,$old['product_id'],$reverse); $up->execute();
                if ($up->affected_rows<1) throw new Exception('The old movement cannot be reversed safely.');

                $st=$conn->prepare("SELECT id FROM products WHERE id=? FOR UPDATE"); $st->bind_param('i',$product); $st->execute();
                if (!$st->get_result()->fetch_assoc()) throw new Exception('Product not found.');
                $up=$conn->prepare("UPDATE products SET stock_qty=stock_qty+? WHERE id=? AND stock_qty+? >= 0");
                $up->bind_param('iii',$deltaNew,$product,$deltaNew); $up->execute();
                if ($up->affected_rows<1) throw new Exception('The new movement would make stock negative.');

                $st=$conn->prepare("UPDATE inventory_movements SET product_id=?,movement_type=?,qty=?,unit_cost=?,reference_no=?,notes=?,adjustment_direction=? WHERE id=? AND source_type='MANUAL'");
                $st->bind_param('isidsssi',$product,$type,$qty,$unit_cost,$reference,$notes,$direction,$id); $st->execute();
                audit_log('UPDATE','Inventory','Manual movement ID '.$id.' updated');
                $msg='Inventory movement updated successfully.';
            } else {
                $st=$conn->prepare("SELECT id,stock_qty FROM products WHERE id=? FOR UPDATE"); $st->bind_param('i',$product); $st->execute(); $pr=$st->get_result()->fetch_assoc();
                if (!$pr) throw new Exception('Product not found.');
                if ((int)$pr['stock_qty']+$deltaNew<0) throw new Exception('Stock OUT/adjustment cannot make inventory negative.');
                $up=$conn->prepare("UPDATE products SET stock_qty=stock_qty+? WHERE id=?"); $up->bind_param('ii',$deltaNew,$product); $up->execute();
                $uid=(int)$_SESSION['user_id'];
                $st=$conn->prepare("INSERT INTO inventory_movements(product_id,movement_type,qty,unit_cost,reference_no,notes,user_id,source_type,adjustment_direction) VALUES(?,?,?,?,?,?,?,'MANUAL',?)");
                $st->bind_param('isidssis',$product,$type,$qty,$unit_cost,$reference,$notes,$uid,$direction); $st->execute();
                audit_log('CREATE','Inventory','Manual '.$type.' movement for Product ID '.$product.' Qty '.$qty);
                $msg='Inventory movement added successfully.';
            }
            $conn->commit(); $edit=null;
        } catch(Throwable $e) { $conn->rollback(); $error=$e->getMessage(); }
    }
}

if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action'] ?? '')==='delete') {
    verify_csrf();
    $id=(int)($_POST['id']??0); $conn->begin_transaction();
    try {
        $st=$conn->prepare("SELECT product_id,movement_type,qty,adjustment_direction FROM inventory_movements WHERE id=? AND source_type='MANUAL' FOR UPDATE");
        $st->bind_param('i',$id); $st->execute(); $old=$st->get_result()->fetch_assoc();
        if (!$old) throw new Exception('Only manual inventory movements can be deleted. POS sale/void movements are protected.');
        $delta=($old['movement_type']==='IN' || ($old['movement_type']==='ADJUSTMENT' && $old['adjustment_direction']==='INCREASE')) ? (int)$old['qty'] : -(int)$old['qty'];
        $reverse=-$delta;
        $up=$conn->prepare("UPDATE products SET stock_qty=stock_qty+? WHERE id=? AND stock_qty+? >= 0");
        $up->bind_param('iii',$reverse,$old['product_id'],$reverse); $up->execute();
        if ($up->affected_rows<1) throw new Exception('The movement cannot be deleted because doing so would create an invalid stock balance.');
        $del=$conn->prepare("DELETE FROM inventory_movements WHERE id=? AND source_type='MANUAL'"); $del->bind_param('i',$id); $del->execute();
        audit_log('DELETE','Inventory','Manual movement ID '.$id.' deleted'); $conn->commit();
        $msg='Inventory movement deleted successfully and stock was reversed.';
    } catch(Throwable $e) { $conn->rollback(); $error=$e->getMessage(); }
}

include '../../includes/header.php';
$products=$conn->query("SELECT id,sku,product_name,stock_qty,reorder_level,status,price FROM products ORDER BY product_name");
$mov=$conn->query("SELECT m.*,p.sku,p.product_name,u.full_name FROM inventory_movements m JOIN products p ON p.id=m.product_id JOIN users u ON u.id=m.user_id ORDER BY m.id DESC LIMIT 500");
$summary=$conn->query("SELECT COUNT(*) products, COALESCE(SUM(stock_qty),0) units, COALESCE(SUM(stock_qty*price),0) value, SUM(stock_qty<=reorder_level) low, SUM(stock_qty=0) outofstock FROM products WHERE status='Active'")->fetch_assoc();
?>
<div class="alert alert-success py-2"><i class="fas fa-shield-alt mr-1"></i><strong><?=is_admin()?'Administrator':'Cashier'?> access:</strong> You can use Inventory CRUD. POS-generated SALE/VOID movements remain protected.</div>
<div class="d-flex justify-content-between align-items-center mb-3">
  <div><h2 class="mb-0">Inventory Management <span class="badge badge-primary align-middle">CRUD</span></h2><small class="text-muted">Complete stock control: receipts, issues, adjustments, stock cards and protected POS movements.</small></div>
  <a href="#inventoryForm" class="btn btn-success mr-2"><i class="fas fa-plus mr-1"></i>Add Inventory Movement</a>
  <a href="<?=BASE_URL?>/modules/reports/inventory.php" class="btn btn-outline-primary"><i class="fas fa-chart-bar mr-1"></i> Inventory Reports</a>
</div>
<?php if($msg):?><div class="alert alert-success"><i class="fas fa-check-circle mr-1"></i><?=h($msg)?></div><?php endif;?>
<?php if($error):?><div class="alert alert-danger"><i class="fas fa-exclamation-circle mr-1"></i><?=h($error)?></div><?php endif;?>
<div class="row">
 <div class="col-lg-3 col-6"><div class="small-box bg-info"><div class="inner"><h3><?=number_format((int)$summary['units'])?></h3><p>Units in Stock</p></div><div class="icon"><i class="fas fa-cubes"></i></div></div></div>
 <div class="col-lg-3 col-6"><div class="small-box bg-success"><div class="inner"><h3><?=CURRENCY?><?=number_format((float)$summary['value'],2)?></h3><p>Inventory Value</p></div><div class="icon"><i class="fas fa-peso-sign"></i></div></div></div>
 <div class="col-lg-3 col-6"><div class="small-box bg-warning"><div class="inner"><h3><?=number_format((int)$summary['low'])?></h3><p>Low Stock</p></div><div class="icon"><i class="fas fa-exclamation-triangle"></i></div></div></div>
 <div class="col-lg-3 col-6"><div class="small-box bg-danger"><div class="inner"><h3><?=number_format((int)$summary['outofstock'])?></h3><p>Out of Stock</p></div><div class="icon"><i class="fas fa-times-circle"></i></div></div></div>
</div>
<?php if($view): ?>
<div class="card card-info">
 <div class="card-header"><h3 class="card-title"><i class="fas fa-eye mr-1"></i>View Inventory Movement #<?=h($view['id'])?></h3><div class="card-tools"><a href="<?=BASE_URL?>/modules/inventory/index.php" class="btn btn-sm btn-light">Close</a></div></div>
 <div class="card-body"><div class="row">
  <div class="col-md-3"><strong>Date</strong><br><?=h($view['movement_date'])?></div>
  <div class="col-md-3"><strong>Product</strong><br><?=h($view['sku'].' - '.$view['product_name'])?></div>
  <div class="col-md-2"><strong>Type</strong><br><?=h($view['movement_type'])?></div>
  <div class="col-md-2"><strong>Source</strong><br><?=h($view['source_type'])?></div>
  <div class="col-md-2"><strong>Quantity</strong><br><?=h($view['qty'])?></div>
  <div class="col-md-3 mt-3"><strong>Unit Cost</strong><br><?=CURRENCY?><?=number_format((float)$view['unit_cost'],2)?></div>
  <div class="col-md-3 mt-3"><strong>Reference</strong><br><?=h($view['reference_no'] ?? '')?></div>
  <div class="col-md-3 mt-3"><strong>User</strong><br><?=h($view['full_name'])?></div>
  <div class="col-md-3 mt-3"><strong>Adjustment</strong><br><?=h($view['adjustment_direction'] ?? '')?></div>
  <div class="col-12 mt-3"><strong>Notes</strong><br><?=nl2br(h($view['notes'] ?? ''))?></div>
 </div></div>
</div>
<?php endif; ?>
<div class="card card-primary" id="inventoryForm">
 <div class="card-header"><h3 class="card-title"><i class="fas fa-exchange-alt mr-1"></i><?= $edit?'Edit Manual Movement':'Record Inventory Movement' ?></h3></div>
 <div class="card-body">
  <div class="alert alert-info py-2"><i class="fas fa-info-circle mr-1"></i><strong>Full Inventory CRUD:</strong> Create, Read, Update and Delete manual stock movements below. POS sales and voids update inventory automatically and remain protected.</div>
  <form method="post" class="row">
   <input type="hidden" name="csrf_token" value="<?=h(csrf_token())?>"><input type="hidden" name="id" value="<?=h($edit['id']??0)?>">
   <div class="col-md-4 mb-2"><label>Product</label><select name="product_id" class="form-control" required><option value="">Select product</option><?php while($p=$products->fetch_assoc()):?><option value="<?=$p['id']?>" <?=((int)($edit['product_id']??0)===(int)$p['id'])?'selected':''?>><?=h($p['sku'].' - '.$p['product_name'])?> (Stock <?=$p['stock_qty']?>)</option><?php endwhile;?></select></div>
   <div class="col-md-2 mb-2"><label>Movement</label><select name="movement_type" id="movement_type" class="form-control" onchange="toggleAdjustment()"><option value="IN" <?=($edit['movement_type']??'IN')==='IN'?'selected':''?>>Stock IN</option><option value="OUT" <?=($edit['movement_type']??'')==='OUT'?'selected':''?>>Stock OUT</option><option value="ADJUSTMENT" <?=($edit['movement_type']??'')==='ADJUSTMENT'?'selected':''?>>Adjustment</option></select></div>
   <div class="col-md-2 mb-2" id="adjustmentWrap"><label>Adjustment</label><select name="adjustment_direction" class="form-control"><option value="INCREASE" <?=($edit['adjustment_direction']??'INCREASE')==='INCREASE'?'selected':''?>>Increase</option><option value="DECREASE" <?=($edit['adjustment_direction']??'')==='DECREASE'?'selected':''?>>Decrease</option></select></div>
   <div class="col-md-2 mb-2"><label>Quantity</label><input name="qty" type="number" min="1" class="form-control" required value="<?=h($edit['qty']??1)?>"></div>
   <div class="col-md-2 mb-2"><label>Unit Cost</label><input name="unit_cost" type="number" min="0" step="0.01" class="form-control" value="<?=h($edit['unit_cost']??'0.00')?>"></div>
   <div class="col-md-3 mb-2"><label>Reference No.</label><input name="reference_no" class="form-control" maxlength="80" placeholder="PO-0001 / DR-0001" value="<?=h($edit['reference_no']??'')?>"></div>
   <div class="col-md-7 mb-2"><label>Notes</label><input name="notes" class="form-control" maxlength="255" placeholder="Purchase, damaged, physical count, etc." value="<?=h($edit['notes']??'')?>"></div>
   <div class="col-md-2 mb-2 d-flex align-items-end"><button class="btn btn-success btn-block"><i class="fas fa-save mr-1"></i><?= $edit?'Update':'Save' ?></button></div>
   <?php if($edit):?><div class="col-12"><a href="<?=BASE_URL?>/modules/inventory/index.php" class="btn btn-secondary btn-sm">Cancel Edit</a></div><?php endif;?>
  </form>
 </div>
</div>
<div class="card"><div class="card-header"><h3 class="card-title"><i class="fas fa-list mr-1"></i>Inventory Records / Movement History <span class="badge badge-info ml-1">Read / Update / Delete</span></h3><div class="card-tools"><a class="btn btn-sm btn-outline-primary" href="<?=BASE_URL?>/modules/reports/inventory.php">Full Stock Card &amp; Reports</a></div></div>
<div class="card-body table-responsive p-0"><table class="table table-striped table-hover mb-0"><thead><tr><th>Date</th><th>Product</th><th>Type</th><th>Source</th><th>Qty</th><th>Unit Cost</th><th>Reference</th><th>User</th><th>Actions</th></tr></thead><tbody>
<?php while($m=$mov->fetch_assoc()): $sign=($m['movement_type']==='OUT' || ($m['movement_type']==='ADJUSTMENT' && $m['adjustment_direction']==='DECREASE'))?'-':'+'; $badge=$m['movement_type']==='IN'?'success':($m['movement_type']==='OUT'?'danger':'warning'); ?>
<tr><td><?=h($m['movement_date'])?></td><td><b><?=h($m['sku'])?></b><br><?=h($m['product_name'])?></td><td><span class="badge badge-<?=$badge?>"><?=h($m['movement_type'])?><?= $m['movement_type']==='ADJUSTMENT'?' '.h($m['adjustment_direction']):'' ?></span></td><td><?=h($m['source_type'])?></td><td><b><?=$sign.number_format((int)$m['qty'])?></b></td><td><?=CURRENCY?><?=number_format((float)$m['unit_cost'],2)?></td><td><?=h($m['reference_no'])?></td><td><?=h($m['full_name'])?></td><td class="text-nowrap"><a href="?view=<?=$m['id']?>" class="btn btn-sm btn-primary" title="View"><i class="fas fa-eye"></i></a> <?php if($m['source_type']==='MANUAL'):?><a href="?edit=<?=$m['id']?>" class="btn btn-sm btn-info" title="Edit"><i class="fas fa-edit"></i></a> <form method="post" class="d-inline" onsubmit="return confirm('Delete this manual movement and reverse its stock effect?')"><input type="hidden" name="csrf_token" value="<?=h(csrf_token())?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$m['id']?>"><button type="submit" class="btn btn-sm btn-danger" title="Delete"><i class="fas fa-trash"></i></button></form><?php else:?><span class="badge badge-secondary ml-1">Protected</span><?php endif;?></td></tr>
<?php endwhile;?></tbody></table></div></div>
<script>function toggleAdjustment(){var v=document.getElementById('movement_type').value;document.getElementById('adjustmentWrap').style.display=v==='ADJUSTMENT'?'block':'none';}toggleAdjustment();</script>
<?php include '../../includes/footer.php'; ?>
