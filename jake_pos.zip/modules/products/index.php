<?php
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
require_once '../../includes/auth.php'; require_admin();
$msg=''; $error=''; $edit=null;
if(isset($_GET['edit'])){ $id=(int)$_GET['edit']; $st=$conn->prepare("SELECT * FROM products WHERE id=?"); $st->bind_param('i',$id); $st->execute(); $edit=$st->get_result()->fetch_assoc(); }
if(isset($_GET['toggle'])){ $id=(int)$_GET['toggle']; $st=$conn->prepare("UPDATE products SET status=IF(status='Active','Inactive','Active') WHERE id=?"); $st->bind_param('i',$id); $st->execute(); audit_log('STATUS','Products','Product ID '.$id); redirect_to('modules/products/index.php'); }
if($_SERVER['REQUEST_METHOD']==='POST'){
    verify_csrf();
    $id=(int)($_POST['id']??0); $sku=trim($_POST['sku']??''); $name=trim($_POST['product_name']??''); $price=(float)($_POST['price']??0); $stock=(int)($_POST['stock_qty']??0); $reorder=(int)($_POST['reorder_level']??0); $status=$_POST['status']??'Active';
    if($sku===''||$name==='') $error='SKU and product name are required.';
    elseif($price<0||$stock<0||$reorder<0) $error='Price and stock values cannot be negative.';
    elseif(!in_array($status,['Active','Inactive'],true)) $error='Invalid product status.';
    else {
        $conn->begin_transaction();
        try {
            if($id){
                // Stock is controlled by Inventory Management, not by editing the product master.
                $st=$conn->prepare("UPDATE products SET sku=?,product_name=?,price=?,reorder_level=?,status=? WHERE id=?");
                $st->bind_param('ssdisi',$sku,$name,$price,$reorder,$status,$id);
            } else {
                $st=$conn->prepare("INSERT INTO products(sku,product_name,price,stock_qty,reorder_level,status) VALUES(?,?,?,?,?,?)");
                $st->bind_param('ssdiis',$sku,$name,$price,$stock,$reorder,$status);
            }
            $st->execute();
            if(!$id && $stock>0){
                $newId=$conn->insert_id; $uid=(int)$_SESSION['user_id']; $note='Opening inventory for new product'; $ref='OPENING'; $cost=$price;
                $mv=$conn->prepare("INSERT INTO inventory_movements(product_id,movement_type,qty,unit_cost,reference_no,notes,user_id,source_type) VALUES(?,'IN',?,?,?,?,?,'OPENING')");
                $mv->bind_param('iidssi',$newId,$stock,$cost,$ref,$note,$uid); $mv->execute();
            }
            audit_log($id?'UPDATE':'CREATE','Products',$name); $conn->commit();
            $msg=$id?'Product updated successfully. Stock is managed from Inventory.':'Product created successfully.'; $edit=null;
        } catch(Throwable $e) { $conn->rollback(); $error=$e->getCode()==='23000'?'That SKU is already in use.':'Unable to save the product: '.$e->getMessage(); }
    }
}
include '../../includes/header.php'; $q=$conn->query("SELECT * FROM products ORDER BY id DESC");
?>
<div class="d-flex justify-content-between align-items-center mb-3"><div><h2 class="mb-0">Product Management</h2><small class="text-muted">Create, edit, activate and deactivate products.</small></div></div>
<?php if($msg):?><div class="alert alert-success"><?=h($msg)?></div><?php endif;?><?php if($error):?><div class="alert alert-danger"><?=h($error)?></div><?php endif;?>
<div class="card card-primary"><div class="card-header"><h3 class="card-title"><?= $edit?'Edit Product':'Add Product' ?></h3></div><div class="card-body"><form method="post" class="row"><input type="hidden" name="csrf_token" value="<?=h(csrf_token())?>"><input type="hidden" name="id" value="<?=h($edit['id']??0)?>">
<div class="col-md-2 mb-2"><label>SKU</label><input name="sku" class="form-control" required value="<?=h($edit['sku']??'')?>"></div><div class="col-md-3 mb-2"><label>Product Name</label><input name="product_name" class="form-control" required value="<?=h($edit['product_name']??'')?>"></div><div class="col-md-2 mb-2"><label>Price</label><input name="price" type="number" min="0" step="0.01" class="form-control" required value="<?=h($edit['price']??'0.00')?>"></div><div class="col-md-2 mb-2"><label><?= $edit?'Current Stock':'Opening Stock' ?></label><input name="stock_qty" type="number" min="0" class="form-control" <?= $edit?'readonly':'required' ?> value="<?=h($edit['stock_qty']??0)?>"><?= $edit?'<small class="text-muted">Use Inventory Management to change stock.</small>':'' ?></div><div class="col-md-1 mb-2"><label>Reorder</label><input name="reorder_level" type="number" min="0" class="form-control" value="<?=h($edit['reorder_level']??5)?>"></div><div class="col-md-2 mb-2"><label>Status</label><select name="status" class="form-control"><option <?=($edit['status']??'Active')==='Active'?'selected':''?>>Active</option><option <?=($edit['status']??'')==='Inactive'?'selected':''?>>Inactive</option></select></div>
<div class="col-12"><button class="btn btn-success"><i class="fas fa-save mr-1"></i><?= $edit?'Update Product':'Create Product' ?></button><?php if($edit):?><a href="<?=BASE_URL?>/modules/products/index.php" class="btn btn-secondary ml-2">Cancel</a><?php endif;?></div></form></div></div>
<div class="card"><div class="card-header"><h3 class="card-title">Product List</h3></div><div class="card-body table-responsive p-0"><table class="table table-striped table-hover mb-0"><thead><tr><th>ID</th><th>SKU</th><th>Product</th><th>Price</th><th>Stock</th><th>Reorder</th><th>Status</th><th class="text-right">Actions</th></tr></thead><tbody>
<?php while($p=$q->fetch_assoc()): ?><tr><td><?=$p['id']?></td><td><?=h($p['sku'])?></td><td><?=h($p['product_name'])?></td><td>₱<?=number_format($p['price'],2)?></td><td><span class="badge badge-<?=$p['stock_qty']<=$p['reorder_level']?'danger':'success'?>"><?=$p['stock_qty']?></span></td><td><?=$p['reorder_level']?></td><td><?=h($p['status'])?></td><td class="text-right text-nowrap"><a href="?edit=<?=$p['id']?>" class="btn btn-sm btn-info"><i class="fas fa-edit"></i> Edit</a> <a href="?toggle=<?=$p['id']?>" onclick="return confirm('Change product status?')" class="btn btn-sm btn-<?=$p['status']==='Active'?'warning':'success'?>"><?=$p['status']==='Active'?'Deactivate':'Activate'?></a></td></tr><?php endwhile; ?></tbody></table></div></div>
<?php include '../../includes/footer.php'; ?>
