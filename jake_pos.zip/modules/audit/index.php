<?php
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
require_once '../../includes/auth.php'; require_login();
$isAdmin=(($_SESSION['role']??'')==='Administrator');$uid=(int)($_SESSION['user_id']??0);$from=$_GET['from']??date('Y-m-d');$to=$_GET['to']??date('Y-m-d');$action=trim($_GET['action']??'');
$sql="SELECT a.*,u.full_name FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id WHERE DATE(a.created_at) BETWEEN ? AND ?";
if(!$isAdmin) $sql.=" AND a.user_id=?";
if($action!=='') $sql.=" AND a.action=?";
$sql.=" ORDER BY a.id DESC LIMIT 500";
$st=$conn->prepare($sql);
if(!$isAdmin && $action!=='') $st->bind_param('ssis',$from,$to,$uid,$action);
elseif(!$isAdmin) $st->bind_param('ssi',$from,$to,$uid);
elseif($action!=='') $st->bind_param('sss',$from,$to,$action);
else $st->bind_param('ss',$from,$to);
$st->execute();$q=$st->get_result();
include '../../includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3"><div><h2 class="mb-0">Audit Journal</h2><small class="text-muted">Immutable activity history for accountability and transaction tracing.</small></div><span class="badge badge-<?=$isAdmin?'primary':'info'?> p-2"><?=$isAdmin?'Administrator: Full Journal':'Cashier: My Activity'?></span></div>
<div class="alert alert-info"><i class="fas fa-shield-alt mr-1"></i>Audit entries are intentionally read-only. They should not be edited or deleted because they provide the system's accountability trail.</div>
<div class="card"><div class="card-header"><form class="form-inline"><label class="mr-2">From</label><input type="date" name="from" value="<?=h($from)?>" class="form-control mr-2"><label class="mr-2">To</label><input type="date" name="to" value="<?=h($to)?>" class="form-control mr-2"><select name="action" class="form-control mr-2"><option value="">All actions</option><?php foreach(['LOGIN','LOGOUT','CREATE','UPDATE','STATUS','STOCK_IN','STOCK_OUT','SALE','VOID','DELETE'] as $a):?><option <?=($action===$a?'selected':'')?>><?=$a?></option><?php endforeach;?></select><button class="btn btn-secondary">Filter</button><button type="button" onclick="window.print()" class="btn btn-primary ml-2">Print</button></form></div>
<div class="card-body table-responsive p-0"><table class="table table-sm table-bordered table-hover mb-0"><thead><tr><th>Date/Time</th><th>User</th><th>Action</th><th>Module</th><th>Details</th><th>IP</th></tr></thead><tbody><?php if($q->num_rows):while($a=$q->fetch_assoc()):?><tr><td><?=h($a['created_at'])?></td><td><?=h($a['full_name']?:'System')?></td><td><?=h($a['action'])?></td><td><?=h($a['module'])?></td><td><?=h($a['details'])?></td><td><?=h($a['ip_address'])?></td></tr><?php endwhile;else:?><tr><td colspan="6" class="text-center p-4">No activity found for the selected filters.</td></tr><?php endif;?></tbody></table></div></div>
<?php include '../../includes/footer.php'; ?>
