<?php
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
require_once '../../includes/auth.php'; require_admin();
$msg='';$error='';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['void_sale'])){
 verify_csrf();$id=(int)($_POST['sale_id']??0);$conn->begin_transaction();
 try{
   $st=$conn->prepare("SELECT id,invoice_no,status FROM sales WHERE id=? FOR UPDATE");$st->bind_param('i',$id);$st->execute();$sale=$st->get_result()->fetch_assoc();if(!$sale)throw new Exception('Sale not found.');if($sale['status']!=='Completed')throw new Exception('Only completed sales can be voided.');
   $it=$conn->prepare("SELECT product_id,qty FROM sale_items WHERE sale_id=?");$it->bind_param('i',$id);$it->execute();$items=$it->get_result();$up=$conn->prepare("UPDATE products SET stock_qty=stock_qty+? WHERE id=?");$mv=$conn->prepare("INSERT INTO inventory_movements(product_id,movement_type,qty,unit_cost,reference_no,notes,user_id,source_type,sale_id) VALUES(?,'IN',?,?,?,?,?,'VOID',?)");$uid=(int)$_SESSION['user_id'];while($x=$items->fetch_assoc()){$qty=(int)$x['qty'];$pid=(int)$x['product_id'];$up->bind_param('ii',$qty,$pid);$up->execute();$note='Voided POS Sale '.$sale['invoice_no'];$ref=$sale['invoice_no'];$cost=0.0;$mv->bind_param('iidssii',$pid,$qty,$cost,$ref,$note,$uid,$id);$mv->execute();}
   $st=$conn->prepare("UPDATE sales SET status='Voided' WHERE id=?");$st->bind_param('i',$id);$st->execute();audit_log('VOID','Sales','Invoice '.$sale['invoice_no'].' voided and stock restored');$conn->commit();$msg='Sale '.$sale['invoice_no'].' was voided and inventory was restored.';
 }catch(Throwable $e){$conn->rollback();$error=$e->getMessage();}
}
include '../../includes/header.php';
$from=$_GET['from']??date('Y-m-01');$to=$_GET['to']??date('Y-m-d');$st=$conn->prepare("SELECT s.*,u.full_name,c.customer_name FROM sales s JOIN users u ON u.id=s.user_id LEFT JOIN customers c ON c.id=s.customer_id WHERE DATE(s.sale_date) BETWEEN ? AND ? ORDER BY s.id DESC");$st->bind_param('ss',$from,$to);$st->execute();$q=$st->get_result();
?>
<div class="d-flex justify-content-between align-items-center mb-3"><div><h2 class="mb-0">Sales Management</h2><small class="text-muted">Review transactions, print receipts and void completed sales when authorized.</small></div></div>
<?php if($msg):?><div class="alert alert-success"><?=h($msg)?></div><?php endif;?><?php if($error):?><div class="alert alert-danger"><?=h($error)?></div><?php endif;?>
<div class="card"><div class="card-header"><form class="form-inline"><label class="mr-2">From</label><input type="date" name="from" value="<?=h($from)?>" class="form-control mr-2"><label class="mr-2">To</label><input type="date" name="to" value="<?=h($to)?>" class="form-control mr-2"><button class="btn btn-secondary">Filter</button></form></div><div class="card-body table-responsive p-0"><table class="table table-striped table-hover mb-0"><thead><tr><th>Invoice</th><th>Date</th><th>Customer</th><th>Cashier</th><th>Total</th><th>Status</th><th class="text-right">Actions</th></tr></thead><tbody>
<?php while($s=$q->fetch_assoc()):?><tr><td><b><?=h($s['invoice_no'])?></b></td><td><?=h($s['sale_date'])?></td><td><?=h($s['customer_name']?:'Walk-in Customer')?></td><td><?=h($s['full_name'])?></td><td>₱<?=number_format($s['total'],2)?></td><td><span class="badge badge-<?=$s['status']==='Completed'?'success':'secondary'?>"><?=h($s['status'])?></span></td><td class="text-right text-nowrap"><a href="<?=BASE_URL?>/receipt.php?id=<?=$s['id']?>" target="_blank" class="btn btn-sm btn-info"><i class="fas fa-print"></i> Receipt</a><?php if($s['status']==='Completed'):?><form method="post" class="d-inline" onsubmit="return confirm('Void this sale? Inventory will be restored.')"><input type="hidden" name="csrf_token" value="<?=h(csrf_token())?>"><input type="hidden" name="sale_id" value="<?=$s['id']?>"><button name="void_sale" value="1" class="btn btn-sm btn-danger"><i class="fas fa-ban"></i> Void</button></form><?php endif;?></td></tr><?php endwhile;?></tbody></table></div></div>
<?php include '../../includes/footer.php'; ?>
