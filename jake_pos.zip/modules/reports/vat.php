<?php 
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
require_once '../../includes/auth.php'; include '../../includes/header.php';
$month=$_GET['month']??date('Y-m');
$st=$conn->prepare("SELECT COALESCE(SUM(subtotal),0) net, COALESCE(SUM(vat_amount),0) vat, COALESCE(SUM(total),0) gross, COUNT(*) tx FROM sales WHERE DATE_FORMAT(sale_date,'%Y-%m')=? AND status='Completed'");$st->bind_param("s",$month);$st->execute();$r=$st->get_result()->fetch_assoc();
?>
<div class="card"><div class="card-header"><h3 class="card-title">VAT Report - <?=$month?></h3></div><div class="card-body"><form class="form-inline mb-3"><input type="month" name="month" value="<?=$month?>" class="form-control mr-2"><button class="btn btn-primary">Generate</button></form>
<table class="table table-bordered"><tr><th>VATable Sales (Net of VAT)</th><th>VAT 12%</th><th>Gross Sales</th><th>Transactions</th></tr><tr><td>₱<?=number_format($r['net'],2)?></td><td>₱<?=number_format($r['vat'],2)?></td><td>₱<?=number_format($r['gross'],2)?></td><td><?=$r['tx']?></td></tr></table>
<div class="alert alert-secondary">This summary is designed to support reporting/reconciliation. Verify the applicable tax treatment and current BIR requirements for the taxpayer before official filing.</div>
</div></div><?php include '../../includes/footer.php'; ?>
