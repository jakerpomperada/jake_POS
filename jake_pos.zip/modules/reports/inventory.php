<?php
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
require_once '../../includes/auth.php'; require_login();
include '../../includes/header.php';

$from=$_GET['from']??date('Y-m-01'); $to=$_GET['to']??date('Y-m-d'); $product_id=(int)($_GET['product_id']??0); $view=$_GET['view']??'summary';
$products=$conn->query("SELECT id,sku,product_name,stock_qty,reorder_level,price,status FROM products ORDER BY product_name");
$where="WHERE DATE(m.movement_date) BETWEEN ? AND ?"; $types='ss'; $params=[$from,$to];
if($product_id>0){$where.=" AND m.product_id=?";$types.='i';$params[]=$product_id;}
$st=$conn->prepare("SELECT m.*,p.sku,p.product_name,u.full_name FROM inventory_movements m JOIN products p ON p.id=m.product_id JOIN users u ON u.id=m.user_id $where ORDER BY m.movement_date DESC,m.id DESC");
$bind=[&$types]; foreach($params as $k=>$_){ $bind[]=&$params[$k]; } call_user_func_array([$st,'bind_param'],$bind); $st->execute(); $mov=$st->get_result();
$summary=$conn->query("SELECT COUNT(*) products,COALESCE(SUM(stock_qty),0) units,COALESCE(SUM(stock_qty*price),0) value,SUM(status='Active' AND stock_qty<=reorder_level) low,SUM(status='Active' AND stock_qty=0) outofstock FROM products")->fetch_assoc();
$low=$conn->query("SELECT sku,product_name,stock_qty,reorder_level,price FROM products WHERE status='Active' AND stock_qty<=reorder_level ORDER BY stock_qty,product_name");
?>
<div class="d-flex justify-content-between align-items-center mb-3"><div><h2 class="mb-0">Inventory Reports</h2><small class="text-muted">Stock balances, stock cards, movement history and inventory valuation.</small></div><button onclick="window.print()" class="btn btn-outline-secondary"><i class="fas fa-print mr-1"></i>Print</button></div>
<div class="row"><div class="col-md-3"><div class="info-box"><span class="info-box-icon bg-info"><i class="fas fa-boxes"></i></span><div class="info-box-content"><span class="info-box-text">Products</span><span class="info-box-number"><?=number_format($summary['products'])?></span></div></div></div><div class="col-md-3"><div class="info-box"><span class="info-box-icon bg-success"><i class="fas fa-cubes"></i></span><div class="info-box-content"><span class="info-box-text">Units</span><span class="info-box-number"><?=number_format($summary['units'])?></span></div></div></div><div class="col-md-3"><div class="info-box"><span class="info-box-icon bg-primary"><i class="fas fa-peso-sign"></i></span><div class="info-box-content"><span class="info-box-text">Inventory Value</span><span class="info-box-number"><?=CURRENCY?><?=number_format($summary['value'],2)?></span></div></div></div><div class="col-md-3"><div class="info-box"><span class="info-box-icon bg-warning"><i class="fas fa-exclamation-triangle"></i></span><div class="info-box-content"><span class="info-box-text">Low / Out</span><span class="info-box-number"><?=number_format($summary['low'])?> / <?=number_format($summary['outofstock'])?></span></div></div></div></div>
<div class="card"><div class="card-header"><h3 class="card-title">Report Filters</h3></div><div class="card-body"><form class="row"><div class="col-md-2"><label>From</label><input type="date" name="from" value="<?=h($from)?>" class="form-control"></div><div class="col-md-2"><label>To</label><input type="date" name="to" value="<?=h($to)?>" class="form-control"></div><div class="col-md-4"><label>Product</label><select name="product_id" class="form-control"><option value="0">All Products</option><?php while($p=$products->fetch_assoc()):?><option value="<?=$p['id']?>" <?=$product_id===$p['id']?'selected':''?>><?=h($p['sku'].' - '.$p['product_name'])?></option><?php endwhile;?></select></div><div class="col-md-2"><label>Report</label><select name="view" class="form-control"><option value="summary" <?=$view==='summary'?'selected':''?>>Stock Summary</option><option value="movements" <?=$view==='movements'?'selected':''?>>Movement History</option><option value="low" <?=$view==='low'?'selected':''?>>Low Stock</option></select></div><div class="col-md-2 d-flex align-items-end"><button class="btn btn-primary btn-block">Generate</button></div></form></div></div>
<?php if($view==='low'):?><div class="card"><div class="card-header"><h3 class="card-title">Low / Out of Stock Products</h3></div><div class="card-body table-responsive p-0"><table class="table table-striped mb-0"><thead><tr><th>SKU</th><th>Product</th><th>Stock</th><th>Reorder Level</th><th>Price</th><th>Status</th></tr></thead><tbody><?php while($p=$low->fetch_assoc()):?><tr><td><?=h($p['sku'])?></td><td><?=h($p['product_name'])?></td><td><span class="badge badge-<?=$p['stock_qty']==0?'danger':'warning'?>"><?=$p['stock_qty']?></span></td><td><?=$p['reorder_level']?></td><td><?=CURRENCY?><?=number_format($p['price'],2)?></td><td><?=$p['stock_qty']==0?'OUT OF STOCK':'LOW STOCK'?></td></tr><?php endwhile;?></tbody></table></div></div>
<?php elseif($view==='movements'):?><div class="card"><div class="card-header"><h3 class="card-title">Movement History: <?=h($from)?> to <?=h($to)?></h3></div><div class="card-body table-responsive p-0"><table class="table table-striped mb-0"><thead><tr><th>Date</th><th>SKU</th><th>Product</th><th>Type</th><th>Source</th><th>Qty</th><th>Reference</th><th>User</th><th>Notes</th></tr></thead><tbody><?php while($m=$mov->fetch_assoc()):$sign=($m['movement_type']==='OUT'||($m['movement_type']==='ADJUSTMENT'&&$m['adjustment_direction']==='DECREASE'))?'-':'+';?><tr><td><?=h($m['movement_date'])?></td><td><?=h($m['sku'])?></td><td><?=h($m['product_name'])?></td><td><?=h($m['movement_type'])?><?= $m['movement_type']==='ADJUSTMENT'?' '.h($m['adjustment_direction']):'' ?></td><td><?=h($m['source_type'])?></td><td><?=$sign.$m['qty']?></td><td><?=h($m['reference_no'])?></td><td><?=h($m['full_name'])?></td><td><?=h($m['notes'])?></td></tr><?php endwhile;?></tbody></table></div></div>
<?php else: $stock=$conn->query("SELECT sku,product_name,stock_qty,reorder_level,price,(stock_qty*price) value,status FROM products ORDER BY product_name");?><div class="card"><div class="card-header"><h3 class="card-title">Current Stock Summary</h3></div><div class="card-body table-responsive p-0"><table class="table table-striped mb-0"><thead><tr><th>SKU</th><th>Product</th><th>Stock</th><th>Reorder</th><th>Unit Price</th><th>Inventory Value</th><th>Status</th></tr></thead><tbody><?php while($p=$stock->fetch_assoc()):?><tr><td><?=h($p['sku'])?></td><td><?=h($p['product_name'])?></td><td><span class="badge badge-<?=$p['stock_qty']==0?'danger':($p['stock_qty']<=$p['reorder_level']?'warning':'success')?>"><?=$p['stock_qty']?></span></td><td><?=$p['reorder_level']?></td><td><?=CURRENCY?><?=number_format($p['price'],2)?></td><td><?=CURRENCY?><?=number_format($p['value'],2)?></td><td><?=h($p['status'])?></td></tr><?php endwhile;?></tbody></table></div></div><?php endif; ?>
<?php include '../../includes/footer.php'; ?>
