<?php 
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
require_once '../../includes/auth.php'; include '../../includes/header.php';
$from=$_GET['from']??date('Y-m-01');$to=$_GET['to']??date('Y-m-d');
$st=$conn->prepare("SELECT s.*,u.full_name FROM sales s JOIN users u ON u.id=s.user_id WHERE DATE(s.sale_date) BETWEEN ? AND ? ORDER BY s.id DESC");$st->bind_param("ss",$from,$to);$st->execute();$q=$st->get_result();
?>
<div class="card"><div class="card-header"><h3 class="card-title">Sales / Backend Report</h3><div class="float-right"><a href="<?=BASE_URL?>/modules/sales/index.php" class="btn btn-secondary mr-2">Sales Management</a><button onclick="window.print()" class="btn btn-primary">Print</button></div></div><div class="card-body"><form class="form-inline mb-3"><input type="date" name="from" value="<?=$from?>" class="form-control mr-2"><input type="date" name="to" value="<?=$to?>" class="form-control mr-2"><button class="btn btn-secondary">Filter</button></form>
<table class="table table-bordered"><tr><th>Invoice</th><th>Date</th><th>Cashier</th><th>Subtotal</th><th>VAT</th><th>Total</th><th>Status</th></tr><?php $tot=0;$vat=0;while($s=$q->fetch_assoc()):if($s['status']==='Completed'){$tot+=$s['total'];$vat+=$s['vat_amount'];}?><tr><td><?=h($s['invoice_no'])?></td><td><?=$s['sale_date']?></td><td><?=h($s['full_name'])?></td><td>₱<?=number_format($s['subtotal'],2)?></td><td>₱<?=number_format($s['vat_amount'],2)?></td><td>₱<?=number_format($s['total'],2)?></td><td><?=$s['status']?></td></tr><?php endwhile;?><tr><th colspan="4">TOTALS</th><th>₱<?=number_format($vat,2)?></th><th>₱<?=number_format($tot,2)?></th><th></th></tr></table></div></div>
<?php include '../../includes/footer.php'; ?>
