# JakePOS – BIR-Oriented Implementation Checklist

This checklist is a development aid, not legal or tax certification.

## Implemented in this prototype

- [x] Philippine Peso currency
- [x] 12% VAT calculation
- [x] Sequential invoice numbering
- [x] Invoice/receipt print layout
- [x] X-Reading
- [x] Z-Reading
- [x] Sales/backend report
- [x] VAT report
- [x] Audit Journal/e-Journal
- [x] User roles
- [x] Inventory controls
- [x] Sales transaction records
- [x] Machine/reporting-oriented fields can be extended
- [x] Asia/Manila timezone
- [x] Sample Philippine customer/product data

## Must still be verified/implemented before claiming BIR compliance

- [ ] Actual taxpayer/business registration details
- [ ] Current BIR registration/accreditation/PTU/eAccReg requirements applicable to the deployment
- [ ] Current invoice content/format applicable to the taxpayer
- [ ] Official machine/POS identification details
- [ ] Required documentary submissions
- [ ] Required monthly eSales process and exact report data
- [ ] Formal void/refund controls
- [ ] Non-VAT, VAT-exempt and zero-rated transaction handling if applicable
- [ ] Complete required backend report formats
- [ ] Complete journal retention/export controls
- [ ] Production security and database backup
- [ ] Acceptance testing with the taxpayer and appropriate BIR process

## Current BIR references to verify

- RMO No. 24-2023 – POS/CRM and sales software accreditation framework.
- BIR Enhanced eAccReg – POS/CRM/SPM registration/accreditation services.
- BIR eSales – monthly sales reporting per machine/Machine Identification Number.

Always verify current BIR issuances before deployment.
