# JakePOS Version 1.0
## Philippine POS / Inventory System
**Created by Dr. Jake R. Pomperada, PhD**

This package is a PHP procedural + MySQL POS and inventory prototype using AdminLTE 3.2.

### First page / login
The application now starts at:

`http://localhost/index.php`

**index.php is the login page when nobody is authenticated.** After login, the same index.php displays the dashboard.

`login.php` is retained only as a compatibility redirect to `index.php`.

### Demo accounts
- Administrator: `admin@jakepos.local` / `password`
- Cashier: `cashier@jakepos.local` / `password`

Change demo passwords before actual deployment.

### Installation with XAMPP
1. Extract the folder to `C:\xampp\htdocs\`.
2. Start Apache and MySQL.
3. Open phpMyAdmin.
4. Import `database/jakepos.sql`.
5. Browse to `http://localhost/JakePOS_V1_BIR_Oriented/index.php`.
6. Log in using one of the demo accounts.

The dynamic base URL also allows the folder to be renamed, for example `C:\xampp\htdocs\JakePOS`.

### Modules
- Login / Dashboard
- Point of Sale
- Customer Management CRUD
- Product Management CRUD
- Inventory Movement CRUD
- Sales Management / Void Control
- User Management CRUD
- Audit Journal
- Sales Report
- VAT Report
- X-Reading
- Z-Reading
- Printable Receipt

### CRUD behavior
For customers, products and users, deletion is represented by **Deactivate/Activate** rather than physical deletion. This prevents historical transactions from losing their references.

Inventory movements support true add/edit/delete operations. When an inventory movement is edited or deleted, JakePOS reverses the previous stock effect and applies the new state within a database transaction.

Sales are not physically deleted. Authorized administrators can **Void** a completed sale; JakePOS restores the sold quantities to inventory and records the action in the Audit Journal.

Audit Journal is intentionally read-only. It can be filtered and printed, but entries are not edited or deleted because it is an accountability record.

Reports and X/Z readings are generated views rather than CRUD records; they provide filtering and printing.

### Philippine settings
- Currency: Philippine Peso (₱)
- VAT: 12%
- Timezone: Asia/Manila
- Invoice format: `YYYYMM-000001`
- Sample Philippine addresses/products/customers

### Important BIR note
This is a **BIR-oriented prototype**, not proof of BIR registration, accreditation, or certification. Actual deployment should be reviewed against the taxpayer's current BIR requirements, invoicing configuration, taxpayer information, machine/POS registration requirements, receipt/invoice rules, and applicable reporting requirements.

## Complete Inventory Workflow

JakePOS Version 1.0 includes an integrated inventory workflow:

- Opening stock is recorded as an inventory movement.
- Manual Stock IN, Stock OUT, and Stock Adjustment have CRUD functionality.
- POS completed sales automatically create protected Stock OUT movements.
- Voided POS sales automatically create protected Stock IN/VOID movements.
- POS-generated movements cannot be edited or deleted from Inventory Management.
- Inventory prevents negative stock balances.
- Inventory Dashboard shows units, inventory value, low-stock and out-of-stock counts.
- Inventory Reports provide current stock, low stock, movement history, date filters and product stock cards.
- Product master editing does not directly overwrite stock; stock is controlled through Inventory Management.

### Existing database upgrade

If you already have an older JakePOS database, run `database/upgrade_inventory.sql` once in phpMyAdmin before using the new inventory module. For a fresh installation, simply import `database/jakepos.sql`.
