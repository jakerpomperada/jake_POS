<?php 
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
?>
</div></section></div>
<footer class="main-footer text-center"><strong><?=h(APP_NAME)?></strong> &mdash; Created by <?=h(CREATOR)?></footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<script src="<?=BASE_URL?>/assets/js/jakepos.js"></script>
</body></html>
