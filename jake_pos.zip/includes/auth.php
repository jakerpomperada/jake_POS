<?php
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config/config.php';

function require_login() {
    if (empty($_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
}
function is_admin() {
    return strcasecmp(trim((string)($_SESSION['role'] ?? '')), 'Administrator') === 0;
}
function require_admin() {
    require_login();
    if (!is_admin()) {
        $_SESSION['flash_error'] = 'Administrator permission is required for this management function.';
        header('Location: ' . BASE_URL . '/index.php');
        exit;
    }
}
function redirect_to($path) {
    header('Location: ' . BASE_URL . '/' . ltrim($path, '/'));
    exit;
}
function flash($type, $message) {
    $_SESSION['flash_' . $type] = $message;
}
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function verify_csrf() {
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(419);
        exit('<div style="font-family:Arial,sans-serif;max-width:760px;margin:60px auto;padding:24px;border:1px solid #ddd;border-radius:8px"><h2>Session expired</h2><p>Please go back, refresh the page, and submit the form again.</p></div>');
    }
}
function audit_log($action, $module, $details='') {
    global $conn;
    $uid = isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null;
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $stmt = $conn->prepare("INSERT INTO audit_logs(user_id,action,module,details,ip_address) VALUES(?,?,?,?,?)");
    if ($uid === null) {
        $stmt->bind_param("issss", $uid, $action, $module, $details, $ip);
    } else {
        $stmt->bind_param("issss", $uid, $action, $module, $details, $ip);
    }
    $stmt->execute();
}
function next_invoice_no() {
    global $conn;
    $prefix = date('Ym') . '-';
    $stmt = $conn->prepare("SELECT invoice_no FROM sales WHERE invoice_no LIKE CONCAT(?, '%') ORDER BY id DESC LIMIT 1");
    $stmt->bind_param("s", $prefix);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    $n = $r ? ((int)substr($r['invoice_no'], 7) + 1) : 1;
    return $prefix . str_pad($n, 6, '0', STR_PAD_LEFT);
}
?>
