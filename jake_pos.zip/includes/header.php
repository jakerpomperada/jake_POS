<?php
/*
|--------------------------------------------------------------------------
| JakePOS Version 1.0
| Philippine Point of Sale and Inventory System
|--------------------------------------------------------------------------
| Programming Language : PHP
| Database             : MySQL
| Framework/UI         : AdminLTE
| Created By           : Dr. Jake Rodriguez Pomperada, PhD
| Date Created         : September 29, 2026
| Copyright Owner      : Dr. Jake Rodriguez Pomperada, PhD
|
| This software was developed as an original computer program by
| Dr. Jake Rodriguez Pomperada, PhD.
|
| All rights reserved.
|--------------------------------------------------------------------------
*/
require_once __DIR__ . '/auth.php'; require_login(); ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=h(APP_NAME)?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/all.min.css"><link rel="stylesheet" href="<?=BASE_URL?>/assets/css/jakepos.css"></head>
<body class="hold-transition sidebar-mini layout-fixed"><div class="wrapper">
<nav class="main-header navbar navbar-expand navbar-white navbar-light"><ul class="navbar-nav"><li class="nav-item"><a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a></li></ul>
<ul class="navbar-nav ml-auto"><li class="nav-item"><span class="nav-link"><i class="fas fa-user mr-1"></i><?=h($_SESSION['name']??'')?> <span class="badge badge-primary"><?=h($_SESSION['role']??'')?></span></span></li><li class="nav-item"><a class="nav-link text-danger" href="<?=BASE_URL?>/logout.php"><i class="fas fa-sign-out-alt mr-1"></i>Logout</a></li></ul></nav>
<aside class="main-sidebar sidebar-dark-primary elevation-4"><a href="<?=BASE_URL?>/index.php" class="brand-link"><span class="brand-text font-weight-light"><i class="fas fa-cash-register mr-2"></i>JakePOS</span></a>
<div class="sidebar"><nav class="mt-2"><ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview">
<li class="nav-item"><a href="<?=BASE_URL?>/index.php" class="nav-link"><i class="nav-icon fas fa-tachometer-alt"></i><p>Dashboard</p></a></li>
<li class="nav-item"><a href="<?=BASE_URL?>/pos.php" class="nav-link"><i class="nav-icon fas fa-cash-register"></i><p>Point of Sale</p></a></li>
<li class="nav-item"><a href="<?=BASE_URL?>/modules/customers/index.php" class="nav-link"><i class="nav-icon fas fa-users"></i><p>Customers</p></a></li>
<li class="nav-item"><a href="<?=BASE_URL?>/modules/inventory/index.php" class="nav-link"><i class="nav-icon fas fa-warehouse"></i><p>Inventory CRUD</p></a></li>
<li class="nav-item"><a href="<?=BASE_URL?>/modules/reports/inventory.php" class="nav-link"><i class="nav-icon fas fa-chart-bar"></i><p>Inventory Reports</p></a></li>
<?php if (is_admin()): ?>
<li class="nav-item"><a href="<?=BASE_URL?>/modules/products/index.php" class="nav-link"><i class="nav-icon fas fa-box"></i><p>Products</p></a></li>
<li class="nav-item"><a href="<?=BASE_URL?>/modules/sales/index.php" class="nav-link"><i class="nav-icon fas fa-file-invoice-dollar"></i><p>Sales Management</p></a></li>
<li class="nav-item"><a href="<?=BASE_URL?>/modules/users/index.php" class="nav-link"><i class="nav-icon fas fa-user-cog"></i><p>User Management</p></a></li>
<?php endif; ?>
<li class="nav-header">REPORTS</li><li class="nav-item"><a href="<?=BASE_URL?>/modules/reports/sales.php" class="nav-link"><i class="nav-icon fas fa-chart-line"></i><p>Sales Report</p></a></li>
<li class="nav-item"><a href="<?=BASE_URL?>/modules/reports/vat.php" class="nav-link"><i class="nav-icon fas fa-receipt"></i><p>VAT Report</p></a></li>
<li class="nav-item"><a href="<?=BASE_URL?>/modules/readings/x_reading.php" class="nav-link"><i class="nav-icon fas fa-file-alt"></i><p>X-Reading</p></a></li>
<li class="nav-item"><a href="<?=BASE_URL?>/modules/readings/z_reading.php" class="nav-link"><i class="nav-icon fas fa-file-signature"></i><p>Z-Reading</p></a></li>
<li class="nav-item"><a href="<?=BASE_URL?>/modules/audit/index.php" class="nav-link"><i class="nav-icon fas fa-history"></i><p>Audit Journal</p></a></li>
</ul></nav></div></aside>
<div class="content-wrapper"><section class="content-header"><div class="container-fluid"><div class="d-flex justify-content-between align-items-center"><div><h1><?=h(APP_NAME)?></h1><small>Created by <?=h(CREATOR)?></small></div><div class="text-muted small">Philippine POS &bull; 12% VAT</div></div></div></section>
<section class="content"><div class="container-fluid">
<?php if(!empty($_SESSION['flash_error'])): ?><div class="alert alert-warning alert-dismissible fade show mt-2"><i class="fas fa-lock mr-1"></i><?=h($_SESSION['flash_error'])?><button type="button" class="close" data-dismiss="alert">&times;</button></div><?php unset($_SESSION['flash_error']); endif; ?>
<?php if(!empty($_SESSION['flash_success'])): ?><div class="alert alert-success alert-dismissible fade show mt-2"><i class="fas fa-check-circle mr-1"></i><?=h($_SESSION['flash_success'])?><button type="button" class="close" data-dismiss="alert">&times;</button></div><?php unset($_SESSION['flash_success']); endif; ?>
